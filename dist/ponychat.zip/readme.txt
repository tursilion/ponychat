Not a lot of setup instructions here... in fact this probably won't work from binary, as paths are hard coded in the source. I didn't intend this to run from Windows, since it ultimately serves up a page meant for web display.

For Linux, you need to build from source anyway. Both Windows and Linux define the paths at the top of bibo.cpp.

I can go into detail if anyone actually cares, but it's basically a very loose and not-at-all-academic implemention of the concept of markov chains, except instead of storing probability we just rely on the repetition in the text itself. ;) There's also a lot of pinhole optimizations related to name, adjective and the like.

I did attempt to keep credit on the images, at least in the filename (which IS displayed for that reason).
